#include <iostream>
using namespace std;
int main()
{
    const int basicCoursePrice = 500;      
    const int advancedCoursePrice = 1000;   
    const int professionalCoursePrice = 2000; 
    const double discountRate = 0.15; 
    int basicCourses, advancedCourses, professionalCourses;
    cout << "Enter the number of Basic courses: ";
    cin >> basicCourses;
    cout << "Enter the number of Advanced courses: ";
    cin >> advancedCourses;
    cout << "Enter the number of Professional courses: ";
    cin >> professionalCourses;
    double totalCost = (basicCourses * basicCoursePrice) + (advancedCourses * advancedCoursePrice) +  (professionalCourses * professionalCoursePrice);
    double discountAmount = totalCost * discountRate;
    double finalAmountDue = totalCost - discountAmount;
    cout << "\nTotal cost before discount: Rs " << totalCost << endl;
    cout << "Discount amount: Rs " << discountAmount << endl;
    cout << "Final amount due: Rs " << finalAmountDue << endl;
    return 0;
}