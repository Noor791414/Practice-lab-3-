#include<iostream>
using namespace std;
int main()
{ 
    const int number_of_cookies = 40;
    const int total_servings = 10;
    const int calories_per_serving = 300;
    int number_of_cookies_eaten;
    cout << "Number of cookies eaten: ";
    cin >> number_of_cookies_eaten;
    int calorie_per_cookie =  calories_per_serving / (number_of_cookies / total_servings);
    int calories_consumed = number_of_cookies_eaten * calorie_per_cookie;
    cout << "calories consumed are: " << calories_consumed << endl;
    return 0;
}
    