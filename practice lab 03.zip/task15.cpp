#include<iostream>
using namespace std;

#include<iostream>
using namespace std;

int main()
{
    int fuel, bills, rent, total;
    cout << "Enter the value of fuel: " ;
    cin >> fuel;
    cout << "Enter the value of bills: " ;
    cin >> bills;
    cout << "Enter the value of rent: " ;
    cin >> rent;
    total = fuel + bills + rent;
    cout << "__________________________________________\n ";
    cout << "fuel: " << '\t' << fuel << "\n";
    cout << "bills: " << '\t' << bills <<"\n";
    cout << "rent: " << '\t' << rent << "\n";
    cout << "Total: " << '\t' << total << "\n";
    return 0;
}