#include <iostream>
using namespace std;
int main()
{
    cout << "Hello, Class!\nWelcome to the ITC-Lab Week-03" << std::endl;
    return 0;
}