#include<iostream>
using namespace std;
int main()
{
    float radius, area;
    const float PI = 3.14;
    cout << "Enter the radius of a circle: ";
    cin >> radius;
    area = PI * radius * radius;
    cout << "The area of a circle is: " << area << endl;
    return 0;
}