#include <iostream>
using namespace std;
int main()
{
	int x = 5;
	cout << "the value of x is " << x;
	return 0;
}