#include <iostream>
using namespace std;
int main()
{
    int totalMinutes;
    cout << "Enter the total number of minutes: ";
    cin >> totalMinutes;
    int hours = totalMinutes / 60;
    int minutes = totalMinutes % 60;
    std::cout << totalMinutes << " minutes is equivalent to " << hours << " hours and " << minutes << " minutes." << std::endl;
    return 0;
}
