#include<iostream>
using namespace std;
int main()
{
    int kilograms;
    cout << "Enter the value of weight in kilograms: ";
    cin >> kilograms;
    int meters;
    cout << "Enter the value of height in meters: ";
    cin >> meters;
    int BMI;
    BMI = kilograms / (meters * meters);
    cout << "BMI is: " << BMI << endl;
    return 0;
}