#include<iostream>
using namespace std;
int main()
{
	cout << "Hello, World!";
	int x = 5;
	cout << "x= " << x;
	return 0;
}