#include<iostream>
using namespace std;
int main()
{
	double length, width, area, perimeter;
	cout << " Enter the length of a side of rectangle: ";
	cin >> length;
	cout << " Enter the width of a rectangle: ";
	cin >> width;
	area = length * width;
	perimeter = 2 * (length + width);
	cout << " The area of a rectangle is: " << area << " and " << " The perimeter of a rectangle is: " << endl;
	return 0;
}