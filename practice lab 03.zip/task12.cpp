#include<iostream>
using namespace std;
int main()
{
    int chem, maths, phy,total;
	cout << "Enter value of chemistry:- \n";
	cin >> chem;
	cout << "Enter value of maths:- \n";
	cin >> maths;
	cout << "Enter value of physics:- \n";
	cin >> phy;
	total = chem + phy + maths;
	cout << "_________________________________________________________________________________ \n";
	cout << "Chemistry" << "\tMaths" << "\tPhysics" << "\t        Total" << "\n";
	cout << chem << '\t' << '\t' << maths << '\t' << phy << '\t' << '\t' << total << endl;
	cout << "_________________________________________________________________________________ \n";
	return 0;
}