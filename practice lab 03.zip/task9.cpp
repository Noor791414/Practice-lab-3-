#include <iostream>
using namespace std;
int main()
{
    double width, length, area, perimeter;
    cout << "Enter the width of the rectangle: ";
    cin >> width;
    cout << "Enter the length of the rectangle: ";
    cin >> length;
    area = width * length;
    perimeter = 2 * (width + length);
    cout << "Area of Rectangle: " << area << std::endl;
    cout << "Perimeter of Rectangle: " << perimeter << std::endl;
    return 0;
}