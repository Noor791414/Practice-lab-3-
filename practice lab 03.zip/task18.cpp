#include <iostream>
using namespace std;

int main() {
	int input;
	cout << "Enter a number :" << endl;
	cin >> input;
	int input2 = input + 1;
	int input3 = input + 2;
	int input4 = input + 3;
	int input5 = input + 4;
	int input6 = input + 5;

	cout << "No \t Square \t Cube \n";
	cout << input << "\t" << input * input << "\t" << input * input * input << endl;
	cout << input2 << "\t" << input2 * input2 << "\t" << input2 * input2 * input2 << endl;
	cout << input3 << "\t" << input3 * input3 << "\t" << input3 * input3 * input3 << endl;
	cout << input4 << "\t" << input4 * input4 << "\t" << input4 * input4 * input4 << endl;
	cout << input5 << "\t" << input5 * input5 << "\t" << input5 * input5 * input5 << endl;
	cout << input6 << "\t" << input6 * input6 << "\t" << input6 * input6 * input6 << endl;
}