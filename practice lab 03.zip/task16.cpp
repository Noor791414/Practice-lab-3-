
#include<iostream>
using namespace std;
int main()
{
    int gassoline, miles, MPG;
     gassoline = 12;
     miles = 35;
     MPG = miles / gassoline;
     cout << MPG << endl;
     return 0;
}