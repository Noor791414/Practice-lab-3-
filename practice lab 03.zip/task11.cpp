#include<iostream>
using namespace std;
int main()
{
    int minutes, hours;
    cout << "Enter the number of hours: ";
    cin >> hours;
    cout << "Enter the number of minutes: ";
    cin>> minutes;
    int totalMinutes = (hours * 60) + minutes;
    cout << "The number of minutes are are: " << totalMinutes << endl;
    return 0;
    }