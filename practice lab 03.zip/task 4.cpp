#include <iostream>
using namespace std;
int main()
{
	int a, aSquare;
	cout << "Enter the value of a:";
	cin >> a;
	aSquare = a * a;
	cout << "The value of aSquare is:" << aSquare << endl;
	return 0;
}