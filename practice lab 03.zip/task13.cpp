#include<iostream>
using namespace std;

int main()
{
	int wheat, rice, sugar , quantity[3],value[3];            //quantity[0] = val of wheat, quantity[1] = val of rice,quantity[2] = val of sugar 
	cout << "Enter price of Wheat:- \n";
	cin >> wheat;
	cout << "Enter quantity of Wheat:- \n";
	cin >> quantity[0];
	cout << "Enter value of Rice:- \n";
	cin >> rice;
	cout << "Enter quantity of rice:- \n";
	cin >> quantity[1];
	cout << "Enter value of Sugar:- \n";
	cin >> sugar;
	cout << "Enter quantity of sugar:- \n";
	cin >> quantity[2];
	value[0] = wheat * quantity[0];
	value[1] = rice * quantity[1];
	value[2] = sugar * quantity[2];
	cout << "_________________________________________________________________________________ \n";
	cout << "Value of Wheat: " << value[0] <<"\n";
	cout << "Value of Rice: " << value[1] << "\n";
	cout << "Value of sugar: " << value[2] << "\n";
	cout << "_________________________________________________________________________________ \n";
	return 0;
}