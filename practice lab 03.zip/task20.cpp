#include <iostream>
using namespace std;

int main()
{
    const int gourmetMealPrice = 50;   
    const int standardMealPrice = 30;  
    const int fastMealPrice = 20;      
    int gourmetMealsSold, standardMealsSold, fastMealsSold;
    cout << "Enter the number of Gourmet meals sold: ";
    cin >> gourmetMealsSold;
    cout << "Enter the number of Standard meals sold: ";
    cin >> standardMealsSold;
    cout << "Enter the number of Fast meals sold: ";
    cin >> fastMealsSold;

    int totalRevenue = (gourmetMealsSold * gourmetMealPrice) + (standardMealsSold * standardMealPrice) + (fastMealsSold * fastMealPrice);

    cout << "\nTotal revenue generated from meal sales:  Rs " << totalRevenue << endl;
    return 0;
}    