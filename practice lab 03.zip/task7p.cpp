#include<iostream>
using namespace std;
int main()
{
	double score1, score2, score3, score4, score5, average;
	cout << "Enter the value of score1: ";
	cin >> score1;
	cout << "Enter the value of score2:";
	cin >> score2;
	cout << "Enter the value of score3:";
	cin >> score3;
	cout << "Enter the value of score4:";
	cin >> score4;
	cout << "Enter the value of score5:";
	cin >> score5;
	average = (score1 + score2 + score3 + score4 + score5) / 5;
	cout << "The average value of scores is:" << average << endl;
	return 0;
}