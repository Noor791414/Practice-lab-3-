#include<iostream>
using namespace std;
int main()
{
    int speed, time, distance;
    speed = 20;
    time = 10;
    distance = speed * time;
    cout << "distance: " << distance << endl;
    return 0;
}
  