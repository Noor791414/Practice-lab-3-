#include<iostream>
using namespace std;
int main() 
{
    float radius;
    cout << "Enter the value of radius: ";
    cin >> radius;
    float height;
    cout << "Enter the value of height: ";
    cin >> height;
    const float PI = 3.14;
    float volume;
    volume = PI * radius * radius * height;
    float area;
    area = 2 * PI * radius * (radius + height);
    cout << "The volume of cylinder is: " << volume << endl;
    cout << "The area of cylinder is: " << area << endl;
}